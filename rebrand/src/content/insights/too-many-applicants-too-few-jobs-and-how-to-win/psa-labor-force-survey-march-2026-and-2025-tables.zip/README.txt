Philippine Statistics Authority (PSA), Labor Force Survey, March 2026 and March 2025, final estimates.
Full statistical tables 1 to 11 for each month, as published by the PSA.
Source (March 2026): https://psa.gov.ph/statistics/labor-force-survey/node/1684083411

These tables belong to the Philippine Statistics Authority. They are redistributed here unchanged,
for non-commercial research and educational use, with attribution.
