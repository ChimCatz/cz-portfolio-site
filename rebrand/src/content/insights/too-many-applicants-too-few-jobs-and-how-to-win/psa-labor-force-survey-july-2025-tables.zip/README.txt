Philippine Statistics Authority (PSA), Labor Force Survey, July 2025, final estimates.
Statistical tables 1 to 20, as published by the PSA.
Source: https://psa.gov.ph/statistics/labor-force-survey/node/1684084238

These tables belong to the Philippine Statistics Authority. They are redistributed here unchanged,
for non-commercial research and educational use, with attribution.
