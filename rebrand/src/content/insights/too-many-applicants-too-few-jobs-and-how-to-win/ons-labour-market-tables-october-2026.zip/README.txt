Office for National Statistics (ONS), United Kingdom. Labour market datasets, October 2026 release.
A02 SA: employment, unemployment and inactivity, people aged 16 and over and 16 to 64.
A05 SA and NSA: employment, unemployment and inactivity by age group.
A06 NSA: educational status and labour market status, people aged 16 to 24.
EMP01 SA: full-time, part-time and temporary workers.
RED01 SA: redundancies.
UNEM01 SA: unemployment by age and duration.
CLA01: claimant count.
Source: https://www.ons.gov.uk/employmentandlabourmarket/peopleinwork/employmentandemployeetypes/bulletins/employmentintheuk/march2026/relateddata

Contains public sector information licensed under the Open Government Licence v3.0.
The files are unchanged.
